# REPEL — Website

A modern, single-page marketing site for **REPEL**, a marketing agency that works with creators.

## What's here
- `index.html` — the page (hero, services, how it works, for creators, FAQ, contact)
- `assets/styles.css` — all styling and the brand palette (CSS variables at the top)
- `assets/script.js` — nav, scroll reveal, FAQ, and contact-form handling
- `assets/favicon.svg` — brand mark

## Run locally
It's static — just open `index.html`, or serve the folder:

```bash
cd website
python3 -m http.server 8000
# visit http://localhost:8000
```

## Branding
The colour palette lives in CSS variables at the top of `assets/styles.css`
(`--brand`, `--brand-2`, `--ink`, etc.). Swap those values to drop in official
REPEL brand colours without touching the rest of the styles. Fonts are
Space Grotesk (display) and Inter (body).

## Contact form
The form is front-end only. To receive submissions, point it at a form service
(Formspree, Basin, Getform) or your own endpoint — see `script.js`.
