#!/usr/bin/env bash
# Pushes this project to your GitHub repo using YOUR GitHub login.
# Run it on your Mac from inside the unzipped folder:  bash push.sh
set -e

REPO_URL="https://github.com/antoniowardbiz/repel.git"

git init
git add -A
git commit -m "Add REPEL Telegram bot for content requests" || true
git branch -M main
git remote remove origin 2>/dev/null || true
git remote add origin "$REPO_URL"
echo ""
echo ">>> Pushing to $REPO_URL (you may be asked to log in to GitHub)..."
git push -u origin main
echo ""
echo "Done! Open https://github.com/antoniowardbiz/repel to see your code."
