#!/usr/bin/env python3
"""Entrypoint for the REPEL Telegram bot."""

from bot.app import main

if __name__ == "__main__":
    main()
