"""Plain-text message builders.

Messages are sent without a parse_mode so user-supplied names/details never
break formatting or get misinterpreted as Markdown/HTML.
"""

from __future__ import annotations

import sqlite3
from datetime import datetime
from typing import Optional

from . import db
from .constants import STATUS_LABELS, TYPE_LABELS


def _name(telegram_id: int) -> str:
    user = db.get_user(telegram_id)
    return user["display_name"] if user else f"user {telegram_id}"


def _fmt_dt(iso: str) -> str:
    try:
        return datetime.fromisoformat(iso).strftime("%b %d, %H:%M")
    except (ValueError, TypeError):
        return iso


def request_card(req: sqlite3.Row, *, audience: str = "owner") -> str:
    """Render a request as a readable card.

    audience: "model" | "manager" | "owner" — controls which counterpart name
    is shown.
    """
    lines = [f"#{req['id']} • {TYPE_LABELS.get(req['type'], req['type'])}"]

    if audience == "model":
        lines.append(f"From: {_name(req['requester_id'])}")
    elif audience == "manager":
        lines.append(f"Model: {_name(req['model_id'])}")
    else:  # owner sees both
        lines.append(f"Model: {_name(req['model_id'])}")
        lines.append(f"From: {_name(req['requester_id'])}")

    if req["content_type"]:
        lines.append(f"Content: {req['content_type']}")
    if req["details"]:
        lines.append(f"Details: {req['details']}")

    lines.append(f"Status: {STATUS_LABELS.get(req['status'], req['status'])}")
    if req["eta"]:
        lines.append(f"ETA: {req['eta']}")
    if req["decline_reason"]:
        lines.append(f"Reason: {req['decline_reason']}")

    lines.append(f"Created: {_fmt_dt(req['created_at'])}")
    return "\n".join(lines)


def request_list(requests, *, audience: str, empty: str) -> str:
    if not requests:
        return empty
    blocks = [request_card(r, audience=audience) for r in requests]
    return ("\n" + "—" * 12 + "\n").join(blocks)


def new_request_for_model(req: sqlite3.Row) -> str:
    return (
        "🆕 New request for you\n\n"
        + request_card(req, audience="model")
        + "\n\nTap Accept and I'll ask for an ETA, or Decline."
    )


def summary_for_confirm(model_name: str, type_label: str,
                        content_type: Optional[str], details: Optional[str]) -> str:
    lines = ["Please confirm this request:", "", f"Model: {model_name}", f"Type: {type_label}"]
    if content_type:
        lines.append(f"Content: {content_type}")
    if details:
        lines.append(f"Details: {details}")
    return "\n".join(lines)
