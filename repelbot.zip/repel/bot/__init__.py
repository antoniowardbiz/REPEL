"""REPEL — Telegram content-request bot for chatting agencies."""

__version__ = "0.1.0"
