"""SQLite data-access layer.

Deliberately dependency-free (only the stdlib) so it can be unit-tested without
Telegram. Call ``configure(path)`` then ``init_db()`` once at startup.
"""

from __future__ import annotations

import secrets
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Iterator, Optional, Sequence

from .constants import RequestStatus

_DB_PATH = "repel.db"


def configure(db_path: str) -> None:
    """Point the data layer at a database file."""
    global _DB_PATH
    _DB_PATH = db_path


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@contextmanager
def _conn() -> Iterator[sqlite3.Connection]:
    conn = sqlite3.connect(_DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    telegram_id  INTEGER PRIMARY KEY,
    role         TEXT    NOT NULL,
    display_name TEXT    NOT NULL,
    username     TEXT,
    is_active    INTEGER NOT NULL DEFAULT 1,
    created_at   TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS invites (
    code        TEXT PRIMARY KEY,
    role        TEXT NOT NULL,
    label       TEXT,
    created_by  INTEGER NOT NULL,
    used_by     INTEGER,
    created_at  TEXT NOT NULL,
    used_at     TEXT
);

CREATE TABLE IF NOT EXISTS requests (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    requester_id  INTEGER NOT NULL,
    model_id      INTEGER NOT NULL,
    type          TEXT    NOT NULL,
    content_type  TEXT,
    details       TEXT,
    status        TEXT    NOT NULL,
    eta           TEXT,
    decline_reason TEXT,
    created_at    TEXT    NOT NULL,
    updated_at    TEXT    NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_requests_requester ON requests(requester_id);
CREATE INDEX IF NOT EXISTS idx_requests_model     ON requests(model_id);
CREATE INDEX IF NOT EXISTS idx_requests_status    ON requests(status);
"""


def init_db() -> None:
    with _conn() as c:
        c.executescript(SCHEMA)


# --------------------------------------------------------------------------- #
# Users
# --------------------------------------------------------------------------- #
def create_user(telegram_id: int, role: str, display_name: str,
                username: Optional[str]) -> None:
    """Insert the user if new, then (re)set their role/profile and reactivate."""
    now = _now()
    with _conn() as c:
        c.execute(
            "INSERT OR IGNORE INTO users (telegram_id, role, display_name, username, "
            "is_active, created_at) VALUES (?, ?, ?, ?, 1, ?)",
            (telegram_id, role, display_name, username, now),
        )
        c.execute(
            "UPDATE users SET role = ?, display_name = ?, username = ?, is_active = 1 "
            "WHERE telegram_id = ?",
            (role, display_name, username, telegram_id),
        )


def touch_user(telegram_id: int, display_name: str, username: Optional[str]) -> None:
    """Refresh a known user's display name / username without changing their role."""
    with _conn() as c:
        c.execute(
            "UPDATE users SET display_name = ?, username = ? WHERE telegram_id = ?",
            (display_name, username, telegram_id),
        )


def set_role(telegram_id: int, role: str) -> None:
    with _conn() as c:
        c.execute("UPDATE users SET role = ? WHERE telegram_id = ?", (role, telegram_id))


def set_active(telegram_id: int, active: bool) -> None:
    with _conn() as c:
        c.execute(
            "UPDATE users SET is_active = ? WHERE telegram_id = ?",
            (1 if active else 0, telegram_id),
        )


def get_user(telegram_id: int) -> Optional[sqlite3.Row]:
    with _conn() as c:
        cur = c.execute("SELECT * FROM users WHERE telegram_id = ?", (telegram_id,))
        return cur.fetchone()


def count_users() -> int:
    with _conn() as c:
        cur = c.execute("SELECT COUNT(*) AS n FROM users")
        return int(cur.fetchone()["n"])


def list_by_role(role: str, active_only: bool = True) -> list[sqlite3.Row]:
    query = "SELECT * FROM users WHERE role = ?"
    params: list = [role]
    if active_only:
        query += " AND is_active = 1"
    query += " ORDER BY display_name COLLATE NOCASE"
    with _conn() as c:
        return list(c.execute(query, params).fetchall())


# --------------------------------------------------------------------------- #
# Invites
# --------------------------------------------------------------------------- #
def create_invite(role: str, label: Optional[str], created_by: int) -> str:
    code = secrets.token_urlsafe(8)
    with _conn() as c:
        c.execute(
            "INSERT INTO invites (code, role, label, created_by, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (code, role, label, created_by, _now()),
        )
    return code


def get_invite(code: str) -> Optional[sqlite3.Row]:
    with _conn() as c:
        cur = c.execute("SELECT * FROM invites WHERE code = ?", (code,))
        return cur.fetchone()


def consume_invite(code: str, used_by: int) -> bool:
    """Atomically mark an invite as used. Returns False if missing/already used."""
    with _conn() as c:
        cur = c.execute(
            "UPDATE invites SET used_by = ?, used_at = ? "
            "WHERE code = ? AND used_by IS NULL",
            (used_by, _now(), code),
        )
        return cur.rowcount == 1


# --------------------------------------------------------------------------- #
# Requests
# --------------------------------------------------------------------------- #
def create_request(requester_id: int, model_id: int, type_: str,
                   content_type: Optional[str], details: Optional[str]) -> int:
    now = _now()
    with _conn() as c:
        cur = c.execute(
            "INSERT INTO requests (requester_id, model_id, type, content_type, details, "
            "status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (requester_id, model_id, type_, content_type, details,
             RequestStatus.PENDING.value, now, now),
        )
        return int(cur.lastrowid)


def get_request(request_id: int) -> Optional[sqlite3.Row]:
    with _conn() as c:
        cur = c.execute("SELECT * FROM requests WHERE id = ?", (request_id,))
        return cur.fetchone()


def update_request(request_id: int, **fields) -> None:
    """Update arbitrary columns. Keys are code-controlled (never user input)."""
    if not fields:
        return
    fields["updated_at"] = _now()
    assignments = ", ".join(f"{key} = ?" for key in fields)
    values: list = list(fields.values()) + [request_id]
    with _conn() as c:
        c.execute(f"UPDATE requests SET {assignments} WHERE id = ?", values)


def list_requests_by_requester(requester_id: int, limit: int = 15) -> list[sqlite3.Row]:
    with _conn() as c:
        return list(c.execute(
            "SELECT * FROM requests WHERE requester_id = ? "
            "ORDER BY id DESC LIMIT ?",
            (requester_id, limit),
        ).fetchall())


def list_requests_for_model(model_id: int, statuses: Sequence[str],
                            limit: int = 25) -> list[sqlite3.Row]:
    placeholders = ", ".join("?" for _ in statuses)
    query = (
        f"SELECT * FROM requests WHERE model_id = ? AND status IN ({placeholders}) "
        "ORDER BY id DESC LIMIT ?"
    )
    with _conn() as c:
        return list(c.execute(query, [model_id, *statuses, limit]).fetchall())


def list_recent_requests(limit: int = 15) -> list[sqlite3.Row]:
    with _conn() as c:
        return list(c.execute(
            "SELECT * FROM requests ORDER BY id DESC LIMIT ?", (limit,),
        ).fetchall())
