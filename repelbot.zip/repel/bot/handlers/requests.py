"""Request lifecycle: creation wizard, model actions, listings, notifications."""

from __future__ import annotations

import logging
import sqlite3

from telegram import Update
from telegram.error import Forbidden, TelegramError
from telegram.ext import (
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    ConversationHandler,
    MessageHandler,
    filters,
)

from .. import db, keyboards, texts
from ..constants import (
    RELOAD_CONTENT_TYPES,
    SKIP_WORDS,
    TYPE_LABELS,
    RequestStatus,
    RequestType,
    Role,
)
from .common import menu_for, role_of, send, start

log = logging.getLogger(__name__)

# Conversation states (the two conversations are independent handlers).
NR_MODEL, NR_TYPE, NR_CONTENT, NR_OTHER, NR_DETAILS, NR_CONFIRM = range(6)
MA_ETA, MA_REASON = range(2)


# --------------------------------------------------------------------------- #
# Notifications
# --------------------------------------------------------------------------- #
async def _notify(context, req: sqlite3.Row, header: str, *, exclude=()) -> None:
    """Tell the requester and the owner about a status change (de-duplicated)."""
    text = header + "\n\n" + texts.request_card(req, audience="owner")
    recipients = {req["requester_id"]}
    for owner in db.list_by_role(Role.OWNER.value):
        recipients.add(owner["telegram_id"])
    for chat_id in recipients - set(exclude):
        try:
            await context.bot.send_message(chat_id=chat_id, text=text)
        except TelegramError as exc:  # recipient never started the bot, blocked it, etc.
            log.warning("Could not notify %s about request %s: %s", chat_id, req["id"], exc)


# --------------------------------------------------------------------------- #
# New-request wizard (managers and owner)
# --------------------------------------------------------------------------- #
async def nr_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.callback_query:
        await update.callback_query.answer()
    if role_of(update.effective_user.id) not in (Role.MANAGER.value, Role.OWNER.value):
        await send(update, context, "Only managers can raise requests.")
        return ConversationHandler.END

    models = db.list_by_role(Role.MODEL.value)
    if not models:
        await send(update, context, "There are no models registered yet. Ask the owner to invite one.")
        return ConversationHandler.END

    context.user_data["nr"] = {}
    await send(update, context, "Who is this request for?", reply_markup=keyboards.model_picker(models))
    return NR_MODEL


async def nr_model(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    model_id = int(q.data.split(":")[2])
    model = db.get_user(model_id)
    if model is None or not model["is_active"]:
        await q.edit_message_text("That model is no longer available. Start again with /newrequest.")
        return ConversationHandler.END
    context.user_data["nr"] = {"model_id": model_id, "model_name": model["display_name"]}
    await q.edit_message_text(
        f"Request for {model['display_name']}.\nWhat kind?", reply_markup=keyboards.type_picker())
    return NR_TYPE


async def nr_type(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    req_type = q.data.split(":")[2]
    context.user_data["nr"]["type"] = req_type

    if req_type == RequestType.RELOAD.value:
        await q.edit_message_text("Which content?", reply_markup=keyboards.content_picker())
        return NR_CONTENT

    # custom
    await q.edit_message_text("Describe the custom — what should she create?\n(Send it as a message.)")
    return NR_DETAILS


async def nr_content(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    idx = int(q.data.split(":")[2])
    choice = RELOAD_CONTENT_TYPES[idx]

    if choice.lower().startswith("other"):
        await q.edit_message_text("Type the content type you want reloaded:")
        return NR_OTHER

    context.user_data["nr"]["content_type"] = choice
    await q.edit_message_text(
        f"Content: {choice}.\nAny extra details? (e.g. quantity, theme)\nSend a message, or type "
        "'skip'.")
    return NR_DETAILS


async def nr_other(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (update.message.text or "").strip()
    if not text:
        await send(update, context, "Please type the content type, or /cancel.")
        return NR_OTHER
    context.user_data["nr"]["content_type"] = text
    await send(update, context,
               "Got it. Any extra details? (e.g. quantity, theme)\nSend a message, or type 'skip'.")
    return NR_DETAILS


async def nr_details(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (update.message.text or "").strip()
    data = context.user_data["nr"]
    is_custom = data["type"] == RequestType.CUSTOM.value

    if is_custom:
        if not text:
            await send(update, context, "Please describe the custom, or /cancel.")
            return NR_DETAILS
        data["details"] = text
    else:
        data["details"] = None if text.lower() in SKIP_WORDS else (text or None)

    summary = texts.summary_for_confirm(
        data["model_name"], TYPE_LABELS[data["type"]],
        data.get("content_type"), data.get("details"))
    await send(update, context, summary, reply_markup=keyboards.confirm_picker())
    return NR_CONFIRM


async def nr_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    data = context.user_data.get("nr") or {}
    if "model_id" not in data:
        await q.edit_message_text("Something went wrong. Start again with /newrequest.")
        return ConversationHandler.END

    req_id = db.create_request(
        requester_id=update.effective_user.id,
        model_id=data["model_id"],
        type_=data["type"],
        content_type=data.get("content_type"),
        details=data.get("details"),
    )
    req = db.get_request(req_id)
    context.user_data.pop("nr", None)

    # Deliver straight to the model's inbox.
    delivered = True
    try:
        await context.bot.send_message(
            chat_id=data["model_id"],
            text=texts.new_request_for_model(req),
            reply_markup=keyboards.accept_decline(req_id),
        )
    except Forbidden:
        delivered = False
    except TelegramError as exc:
        delivered = False
        log.warning("Failed to deliver request %s to model: %s", req_id, exc)

    if delivered:
        await q.edit_message_text(
            f"✅ Sent to {data['model_name']} (request #{req_id}). "
            "You'll be notified when she responds.")
    else:
        await q.edit_message_text(
            f"⚠️ Request #{req_id} saved, but I couldn't message {data['model_name']} — "
            "she may not have started the bot yet. Ask her to open her invite link.")

    # Keep the owner in the loop (skip if the owner is the requester).
    await _notify(context, req, "🆕 New request raised", exclude=(update.effective_user.id,))
    return ConversationHandler.END


# --------------------------------------------------------------------------- #
# Model actions: accept (+ETA), decline (+reason), deliver
# --------------------------------------------------------------------------- #
def _owns_request(update: Update, req) -> bool:
    return req is not None and req["model_id"] == update.effective_user.id


async def req_accept(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    req_id = int(q.data.split(":")[2])
    req = db.get_request(req_id)
    if not _owns_request(update, req):
        await q.answer("This request isn't yours.", show_alert=True)
        return ConversationHandler.END
    if req["status"] != RequestStatus.PENDING.value:
        await q.answer("Already handled.")
        return ConversationHandler.END

    await q.answer()
    await q.edit_message_reply_markup(reply_markup=None)
    context.user_data["ma"] = {"id": req_id, "msg": (q.message.chat_id, q.message.message_id)}
    await send(update, context,
               "Great! When will it be ready?\nSend an ETA, e.g. 'Tomorrow 8pm', 'Fri', 'Jun 20'.")
    return MA_ETA


async def ma_eta(update: Update, context: ContextTypes.DEFAULT_TYPE):
    eta = (update.message.text or "").strip()
    ma = context.user_data.get("ma") or {}
    req_id = ma.get("id")
    req = db.get_request(req_id) if req_id else None
    if not _owns_request(update, req) or req["status"] != RequestStatus.PENDING.value:
        context.user_data.pop("ma", None)
        await send(update, context, "That request is no longer pending.")
        return ConversationHandler.END
    if not eta:
        await send(update, context, "Please send an ETA, or /cancel.")
        return MA_ETA

    db.update_request(req_id, status=RequestStatus.ACCEPTED.value, eta=eta)
    req = db.get_request(req_id)
    await _refresh_model_message(context, ma.get("msg"), req, keyboards.mark_delivered(req_id))
    context.user_data.pop("ma", None)

    await send(update, context, f"✅ Accepted. ETA noted: {eta}. I'll let the team know.",
               reply_markup=menu_for(Role.MODEL.value))
    await _notify(context, req, "✅ Request accepted")
    return ConversationHandler.END


async def req_decline(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    req_id = int(q.data.split(":")[2])
    req = db.get_request(req_id)
    if not _owns_request(update, req):
        await q.answer("This request isn't yours.", show_alert=True)
        return ConversationHandler.END
    if req["status"] != RequestStatus.PENDING.value:
        await q.answer("Already handled.")
        return ConversationHandler.END

    await q.answer()
    await q.edit_message_reply_markup(reply_markup=None)
    prompt = await send(update, context, "Okay. Want to add a reason? Send a message, or tap Skip.",
                        reply_markup=keyboards.decline_skip())
    context.user_data["ma"] = {
        "id": req_id,
        "msg": (q.message.chat_id, q.message.message_id),
        "prompt": (prompt.chat_id, prompt.message_id),
    }
    return MA_REASON


async def _finish_decline(update, context, reason):
    ma = context.user_data.get("ma") or {}
    req_id = ma.get("id")
    req = db.get_request(req_id) if req_id else None
    if not _owns_request(update, req) or req["status"] != RequestStatus.PENDING.value:
        context.user_data.pop("ma", None)
        return ConversationHandler.END

    db.update_request(req_id, status=RequestStatus.DENIED.value, decline_reason=reason)
    req = db.get_request(req_id)
    await _refresh_model_message(context, ma.get("msg"), req, None)
    # Drop the "add a reason?" prompt's Skip button so it can't be tapped later.
    prompt = ma.get("prompt")
    if prompt:
        try:
            await context.bot.edit_message_reply_markup(
                chat_id=prompt[0], message_id=prompt[1], reply_markup=None)
        except TelegramError as exc:
            log.debug("Could not clear decline prompt for request %s: %s", req_id, exc)
    context.user_data.pop("ma", None)
    await _notify(context, req, "❌ Request declined")
    return ConversationHandler.END


async def ma_reason(update: Update, context: ContextTypes.DEFAULT_TYPE):
    reason = (update.message.text or "").strip() or None
    result = await _finish_decline(update, context, reason)
    await send(update, context, "Declined. The team has been notified.",
               reply_markup=menu_for(Role.MODEL.value))
    return result


async def ma_reason_skip(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    result = await _finish_decline(update, context, None)  # also clears the Skip button
    await send(update, context, "Declined. The team has been notified.",
               reply_markup=menu_for(Role.MODEL.value))
    return result


async def deliver_cb(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    req_id = int(q.data.split(":")[2])
    req = db.get_request(req_id)
    if not _owns_request(update, req):
        await q.answer("This request isn't yours.", show_alert=True)
        return
    if req["status"] != RequestStatus.ACCEPTED.value:
        await q.answer("This request can't be marked delivered.")
        return
    await q.answer("Marked delivered 📦")
    db.update_request(req_id, status=RequestStatus.DELIVERED.value)
    req = db.get_request(req_id)
    await q.edit_message_text(texts.request_card(req, audience="model"))
    await _notify(context, req, "📦 Request delivered")


async def _refresh_model_message(context, msg, req, reply_markup) -> None:
    if not msg:
        return
    chat_id, message_id = msg
    try:
        await context.bot.edit_message_text(
            chat_id=chat_id, message_id=message_id,
            text=texts.request_card(req, audience="model"), reply_markup=reply_markup)
    except TelegramError as exc:
        log.debug("Could not refresh model message for request %s: %s", req["id"], exc)


# --------------------------------------------------------------------------- #
# Listings
# --------------------------------------------------------------------------- #
async def my_requests_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await _show_my_requests(update, context)


async def queue_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await _show_queue(update, context)


async def menu_cb(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    action = q.data.split(":")[1]
    if action == "myrequests":
        await _show_my_requests(update, context)
    elif action == "queue":
        await _show_queue(update, context)


async def _show_my_requests(update, context) -> None:
    role = role_of(update.effective_user.id)
    if role not in (Role.MANAGER.value, Role.OWNER.value):
        await send(update, context, "Nothing here for your role.")
        return
    rows = db.list_requests_by_requester(update.effective_user.id)
    body = texts.request_list(rows, audience="manager", empty="You haven't raised any requests yet.")
    await send(update, context, "📋 Your requests\n\n" + body)


async def _show_queue(update, context) -> None:
    if role_of(update.effective_user.id) != Role.MODEL.value:
        await send(update, context, "Only models have a request queue.")
        return
    pending = db.list_requests_for_model(
        update.effective_user.id, [RequestStatus.PENDING.value])
    accepted = db.list_requests_for_model(
        update.effective_user.id, [RequestStatus.ACCEPTED.value])

    if not pending and not accepted:
        await send(update, context, "📥 Your queue is empty. Nice!")
        return

    await send(update, context, "📥 Your queue")
    for req in pending:
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=texts.request_card(req, audience="model"),
            reply_markup=keyboards.accept_decline(req["id"]))
    for req in accepted:
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=texts.request_card(req, audience="model"),
            reply_markup=keyboards.mark_delivered(req["id"]))


# --------------------------------------------------------------------------- #
# Conversation handler factories
# --------------------------------------------------------------------------- #
def new_request_conversation() -> ConversationHandler:
    return ConversationHandler(
        entry_points=[
            CommandHandler("newrequest", nr_start),
            CallbackQueryHandler(nr_start, pattern=r"^menu:new$"),
        ],
        states={
            NR_MODEL: [CallbackQueryHandler(nr_model, pattern=r"^nr:model:\d+$")],
            NR_TYPE: [CallbackQueryHandler(nr_type, pattern=r"^nr:type:(custom|reload)$")],
            NR_CONTENT: [CallbackQueryHandler(nr_content, pattern=r"^nr:content:\d+$")],
            NR_OTHER: [MessageHandler(filters.TEXT & ~filters.COMMAND, nr_other)],
            NR_DETAILS: [MessageHandler(filters.TEXT & ~filters.COMMAND, nr_details)],
            NR_CONFIRM: [
                CallbackQueryHandler(nr_confirm, pattern=r"^nr:confirm$"),
                CallbackQueryHandler(nr_cancel, pattern=r"^nr:cancel$"),
            ],
        },
        fallbacks=[
            CallbackQueryHandler(nr_cancel, pattern=r"^nr:cancel$"),
            CommandHandler("cancel", nr_cancel),
            CommandHandler("start", _exit_to_start),
            CommandHandler("help", _exit_to_start),
        ],
        name="new_request",
        persistent=True,
        allow_reentry=True,
    )


async def _exit_to_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Bail out of any in-progress conversation and show the user's menu."""
    context.user_data.pop("nr", None)
    context.user_data.pop("ma", None)
    await start(update, context)
    return ConversationHandler.END


async def nr_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("nr", None)
    role = role_of(update.effective_user.id)
    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text("Cancelled.")
    else:
        await send(update, context, "Cancelled.")
    if role:
        await send(update, context, "Back to your menu.", reply_markup=menu_for(role))
    return ConversationHandler.END


def model_action_conversation() -> ConversationHandler:
    return ConversationHandler(
        entry_points=[
            CallbackQueryHandler(req_accept, pattern=r"^req:accept:\d+$"),
            CallbackQueryHandler(req_decline, pattern=r"^req:decline:\d+$"),
        ],
        states={
            MA_ETA: [MessageHandler(filters.TEXT & ~filters.COMMAND, ma_eta)],
            MA_REASON: [
                CallbackQueryHandler(ma_reason_skip, pattern=r"^req:declineskip$"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, ma_reason),
            ],
        },
        fallbacks=[
            CommandHandler("cancel", _ma_cancel),
            CommandHandler("start", _exit_to_start),
            CommandHandler("help", _exit_to_start),
        ],
        name="model_action",
        persistent=True,
        allow_reentry=True,
    )


async def _ma_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("ma", None)
    await send(update, context, "Cancelled — the request is unchanged.",
               reply_markup=menu_for(Role.MODEL.value))
    return ConversationHandler.END
