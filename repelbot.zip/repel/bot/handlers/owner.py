"""Owner/admin handlers: invites, people management, activity feed."""

from __future__ import annotations

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from .. import db, texts
from ..constants import ROLE_LABELS, Role
from .common import is_owner, role_of, send


async def _bot_username(context: ContextTypes.DEFAULT_TYPE) -> str:
    cached = context.bot_data.get("bot_username")
    if cached:
        return cached
    me = await context.bot.get_me()
    context.bot_data["bot_username"] = me.username
    return me.username


async def _guard(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    if is_owner(update.effective_user.id, context):
        return True
    if update.callback_query:
        await update.callback_query.answer("Owner only.", show_alert=True)
    else:
        await send(update, context, "That command is for the agency owner only.")
    return False


# --------------------------------------------------------------------------- #
# Invites
# --------------------------------------------------------------------------- #
async def _make_invite(update, context, role: str) -> None:
    code = db.create_invite(role, label=None, created_by=update.effective_user.id)
    username = await _bot_username(context)
    link = f"https://t.me/{username}?start={code}"
    label = ROLE_LABELS.get(role, role)
    await send(
        update, context,
        f"➕ One-time {label} invite created.\n\nSend this link to the {label.lower()} — "
        f"it works once:\n{link}",
    )


async def invite_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/invite model|manager"""
    if not await _guard(update, context):
        return
    args = [a.lower() for a in (context.args or [])]
    role = None
    if "model" in args:
        role = Role.MODEL.value
    elif "manager" in args:
        role = Role.MANAGER.value
    if role is None:
        await send(update, context, "Usage: /invite model   — or —   /invite manager")
        return
    await _make_invite(update, context, role)


async def invite_cb(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    await q.answer()
    if not await _guard(update, context):
        return
    role = q.data.split(":")[2]  # owner:invite:<role>
    if role not in (Role.MODEL.value, Role.MANAGER.value):
        return
    await _make_invite(update, context, role)


# --------------------------------------------------------------------------- #
# People
# --------------------------------------------------------------------------- #
def _people_text_and_kb():
    lines = []
    buttons = []
    for role in (Role.MANAGER.value, Role.MODEL.value):
        people = db.list_by_role(role, active_only=False)
        lines.append(f"\n{ROLE_LABELS[role]}s ({sum(1 for p in people if p['is_active'])} active):")
        if not people:
            lines.append("  — none yet")
        for p in people:
            tag = f" @{p['username']}" if p["username"] else ""
            status = "" if p["is_active"] else "  (inactive)"
            lines.append(f"  • {p['display_name']}{tag}{status}")
            if p["is_active"]:
                buttons.append([InlineKeyboardButton(
                    f"🚫 Deactivate {p['display_name']}",
                    callback_data=f"owner:deact:{p['telegram_id']}",
                )])
    text = "👥 People" + ("\n" + "\n".join(lines) if lines else "")
    return text, InlineKeyboardMarkup(buttons) if buttons else None


async def people_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _guard(update, context):
        return
    text, kb = _people_text_and_kb()
    await send(update, context, text, reply_markup=kb)


async def people_cb(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    await q.answer()
    if not await _guard(update, context):
        return
    text, kb = _people_text_and_kb()
    await send(update, context, text, reply_markup=kb)


async def deactivate_cb(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    await q.answer()
    if not await _guard(update, context):
        return
    target_id = int(q.data.split(":")[2])  # owner:deact:<id>
    user = db.get_user(target_id)
    if user is None:
        await q.answer("No such user.", show_alert=True)
        return
    db.set_active(target_id, False)
    await q.answer(f"{user['display_name']} deactivated.")
    text, kb = _people_text_and_kb()
    await q.edit_message_text(text, reply_markup=kb)


# --------------------------------------------------------------------------- #
# Activity feed
# --------------------------------------------------------------------------- #
async def feed_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _guard(update, context):
        return
    await _send_feed(update, context)


async def feed_cb(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.callback_query.answer()
    if not await _guard(update, context):
        return
    await _send_feed(update, context)


async def _send_feed(update, context) -> None:
    requests = db.list_recent_requests(limit=12)
    body = texts.request_list(requests, audience="owner", empty="No requests yet.")
    await send(update, context, "📋 Recent requests\n\n" + body)
