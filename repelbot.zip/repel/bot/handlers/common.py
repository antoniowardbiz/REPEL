"""Onboarding, menus and shared helpers."""

from __future__ import annotations

from typing import Optional

from telegram import Update
from telegram.constants import ChatAction
from telegram.ext import ContextTypes

from .. import db, keyboards
from ..constants import ROLE_LABELS, Role


# --------------------------------------------------------------------------- #
# Shared helpers used across handler modules
# --------------------------------------------------------------------------- #
def role_of(telegram_id: int) -> Optional[str]:
    user = db.get_user(telegram_id)
    if user is None or not user["is_active"]:
        return None
    return user["role"]


def is_owner(telegram_id: int, context: ContextTypes.DEFAULT_TYPE) -> bool:
    return role_of(telegram_id) == Role.OWNER.value


def display_name(update: Update) -> str:
    user = update.effective_user
    return (user.full_name or user.username or str(user.id)).strip()


async def send(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str,
               reply_markup=None):
    """Send a fresh message to the active chat (works for commands & callbacks)."""
    return await context.bot.send_message(
        chat_id=update.effective_chat.id, text=text, reply_markup=reply_markup,
    )


def menu_for(role: str):
    if role == Role.OWNER.value:
        return keyboards.owner_menu()
    if role == Role.MANAGER.value:
        return keyboards.manager_menu()
    if role == Role.MODEL.value:
        return keyboards.model_menu()
    return None


# --------------------------------------------------------------------------- #
# /start  (handles invite deep-links and owner bootstrap)
# --------------------------------------------------------------------------- #
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    tg_user = update.effective_user
    name = display_name(update)
    config = context.bot_data["config"]
    existing = db.get_user(tg_user.id)

    if existing is None:
        await _register_new_user(update, context, name, config)
        return

    # Keep the owner's role correct if OWNER_ID is configured.
    if config.owner_id and tg_user.id == config.owner_id and existing["role"] != Role.OWNER.value:
        db.set_role(tg_user.id, Role.OWNER.value)
        existing = db.get_user(tg_user.id)

    db.touch_user(tg_user.id, name, tg_user.username)

    if not existing["is_active"]:
        await send(update, context, "Your access has been deactivated. Contact the agency owner.")
        return

    await _show_home(update, context, existing["role"], name)


async def _register_new_user(update, context, name, config) -> None:
    tg_user = update.effective_user
    args = context.args or []

    # Owner bootstrap: configured OWNER_ID, or the very first person to /start.
    if (config.owner_id and tg_user.id == config.owner_id) or db.count_users() == 0:
        db.create_user(tg_user.id, Role.OWNER.value, name, tg_user.username)
        await send(
            update, context,
            f"👑 Welcome, {name}. You're set up as the agency owner.\n\n"
            "Invite your models and chatting managers from the menu below — each "
            "gets a one-time link.",
            reply_markup=keyboards.owner_menu(),
        )
        return

    # Otherwise an invite code is required (sent as the /start deep-link payload).
    if args:
        await _redeem_invite(update, context, args[0].strip(), name)
        return

    await send(
        update, context,
        "👋 Hi! This bot is invite-only.\n\nAsk the agency owner for your personal "
        "invite link, then tap it to get started.",
    )


async def _redeem_invite(update, context, code: str, name: str) -> None:
    tg_user = update.effective_user
    invite = db.get_invite(code)
    if invite is None or invite["used_by"] is not None:
        await send(
            update, context,
            "That invite link is invalid or has already been used. Ask the owner for a new one.",
        )
        return

    if not db.consume_invite(code, tg_user.id):  # lost a race
        await send(update, context, "That invite link has just been used. Ask the owner for a new one.")
        return

    role = invite["role"]
    db.create_user(tg_user.id, role, name, tg_user.username)
    await _show_home(update, context, role,
                     name, prefix=f"✅ You're registered as a {ROLE_LABELS.get(role, role)}.\n\n")


async def _show_home(update, context, role: str, name: str, prefix: str = "") -> None:
    if role == Role.OWNER.value:
        body = "👑 Owner menu — you can see and manage everything."
    elif role == Role.MANAGER.value:
        body = (f"Hi {name}! Use the menu to request customs or content reloads "
                "from your models.")
    else:  # model
        body = (f"Hi {name}! Requests from your team land right here. You'll get a "
                "message to Accept/Decline and add an ETA. Tap below to see your queue.")
    await send(update, context, prefix + body, reply_markup=menu_for(role))


# --------------------------------------------------------------------------- #
# /help and /cancel
# --------------------------------------------------------------------------- #
async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    role = role_of(update.effective_user.id)
    if role is None:
        await send(update, context, "You're not registered. Ask the agency owner for an invite link.")
        return

    common_lines = ["/start — open your menu", "/help — show this help", "/cancel — stop the current step"]
    if role == Role.OWNER.value:
        extra = [
            "/invite model | manager — create an invite link",
            "/people — list everyone",
            "/feed — recent requests",
            "/newrequest — raise a request yourself",
        ]
    elif role == Role.MANAGER.value:
        extra = ["/newrequest — request a custom or content reload", "/myrequests — your requests & status"]
    else:
        extra = ["/queue — your pending & accepted requests"]

    await send(update, context, "\n".join([f"You're a {ROLE_LABELS.get(role, role)}.", "", *extra, "", *common_lines]),
               reply_markup=menu_for(role))


async def cancel_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    role = role_of(update.effective_user.id)
    await send(update, context, "Okay, cancelled.", reply_markup=menu_for(role) if role else None)
    from telegram.ext import ConversationHandler
    return ConversationHandler.END


# --------------------------------------------------------------------------- #
# Low-priority fallback for stray text (the "just talk to the bot" nudge)
# --------------------------------------------------------------------------- #
async def fallback_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    role = role_of(update.effective_user.id)
    if role in (Role.MANAGER.value, Role.OWNER.value):
        await send(
            update, context,
            "Want to send that as a request? Tap below and I'll walk you through it.",
            reply_markup=keyboards.manager_menu() if role == Role.MANAGER.value else keyboards.owner_menu(),
        )
    elif role == Role.MODEL.value:
        await send(update, context, "Tap below to see your current requests.",
                   reply_markup=keyboards.model_menu())
    else:
        await send(update, context, "You're not registered. Ask the agency owner for an invite link.")
