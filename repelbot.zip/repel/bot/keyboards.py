"""Inline keyboard builders.

Callback-data scheme: "<namespace>:<action>[:<arg>]"
  menu:*    generic role menus
  nr:*      new-request wizard
  req:*     model actions on a request
  owner:*   owner/admin actions
"""

from __future__ import annotations

from typing import Sequence

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from .constants import RELOAD_CONTENT_TYPES


def _rows(buttons: Sequence[InlineKeyboardButton], per_row: int = 1):
    return [list(buttons[i:i + per_row]) for i in range(0, len(buttons), per_row)]


# --------------------------------------------------------------------------- #
# Role menus
# --------------------------------------------------------------------------- #
def owner_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📝 New request", callback_data="menu:new")],
        [
            InlineKeyboardButton("➕ Invite model", callback_data="owner:invite:model"),
            InlineKeyboardButton("➕ Invite manager", callback_data="owner:invite:manager"),
        ],
        [
            InlineKeyboardButton("👥 People", callback_data="owner:people"),
            InlineKeyboardButton("📋 All requests", callback_data="owner:feed"),
        ],
    ])


def manager_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📝 New request", callback_data="menu:new")],
        [InlineKeyboardButton("📋 My requests", callback_data="menu:myrequests")],
    ])


def model_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📥 My queue", callback_data="menu:queue")],
    ])


# --------------------------------------------------------------------------- #
# New-request wizard
# --------------------------------------------------------------------------- #
def model_picker(models) -> InlineKeyboardMarkup:
    buttons = [
        InlineKeyboardButton(m["display_name"], callback_data=f"nr:model:{m['telegram_id']}")
        for m in models
    ]
    rows = _rows(buttons, per_row=2)
    rows.append([InlineKeyboardButton("✖ Cancel", callback_data="nr:cancel")])
    return InlineKeyboardMarkup(rows)


def type_picker() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🎬 Custom", callback_data="nr:type:custom"),
            InlineKeyboardButton("🔁 Content reload", callback_data="nr:type:reload"),
        ],
        [InlineKeyboardButton("✖ Cancel", callback_data="nr:cancel")],
    ])


def content_picker() -> InlineKeyboardMarkup:
    buttons = [
        InlineKeyboardButton(name, callback_data=f"nr:content:{i}")
        for i, name in enumerate(RELOAD_CONTENT_TYPES)
    ]
    rows = _rows(buttons, per_row=2)
    rows.append([InlineKeyboardButton("✖ Cancel", callback_data="nr:cancel")])
    return InlineKeyboardMarkup(rows)


def confirm_picker() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✅ Send request", callback_data="nr:confirm"),
            InlineKeyboardButton("✖ Cancel", callback_data="nr:cancel"),
        ],
    ])


# --------------------------------------------------------------------------- #
# Model actions on a request
# --------------------------------------------------------------------------- #
def accept_decline(request_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("✅ Accept", callback_data=f"req:accept:{request_id}"),
        InlineKeyboardButton("❌ Decline", callback_data=f"req:decline:{request_id}"),
    ]])


def mark_delivered(request_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("📦 Mark delivered", callback_data=f"req:deliver:{request_id}"),
    ]])


def decline_skip() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("Skip reason", callback_data="req:declineskip"),
    ]])
