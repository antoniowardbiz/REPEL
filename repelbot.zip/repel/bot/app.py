"""Application assembly: wire handlers, persistence and run the bot."""

from __future__ import annotations

import logging

from telegram import BotCommand, Update
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    PicklePersistence,
    filters,
)

from . import db
from .config import Config, load_config
from .handlers import common, owner, requests

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s", level=logging.INFO)
log = logging.getLogger("repel")


async def _post_init(app: Application) -> None:
    me = await app.bot.get_me()
    app.bot_data["bot_username"] = me.username
    await app.bot.set_my_commands([
        BotCommand("start", "Open your menu"),
        BotCommand("newrequest", "Request a custom or content reload"),
        BotCommand("myrequests", "Your requests & their status"),
        BotCommand("queue", "Models: your request queue"),
        BotCommand("invite", "Owner: create an invite link"),
        BotCommand("people", "Owner: list everyone"),
        BotCommand("feed", "Owner: recent requests"),
        BotCommand("help", "Show help"),
        BotCommand("cancel", "Stop the current step"),
    ])
    log.info("REPEL is running as @%s", me.username)


async def _on_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    log.exception("Unhandled error while processing update: %s", context.error)


def build_application(config: Config) -> Application:
    db.configure(config.db_path)
    db.init_db()

    persistence = PicklePersistence(filepath=config.state_path)
    app = (
        Application.builder()
        .token(config.bot_token)
        .persistence(persistence)
        .post_init(_post_init)
        .build()
    )
    app.bot_data["config"] = config

    # --- group 0: primary handlers ---
    # Conversations are registered FIRST so that while one is active it can
    # intercept /start, /cancel and /help (via its fallbacks) and end cleanly,
    # instead of the global command handlers leaving it dangling.
    app.add_handler(requests.new_request_conversation())
    app.add_handler(requests.model_action_conversation())

    # Global commands (used when no conversation is active).
    app.add_handler(CommandHandler("start", common.start))
    app.add_handler(CommandHandler("help", common.help_cmd))
    app.add_handler(CommandHandler("cancel", common.cancel_cmd))

    # Owner / admin
    app.add_handler(CommandHandler("invite", owner.invite_cmd))
    app.add_handler(CommandHandler("people", owner.people_cmd))
    app.add_handler(CommandHandler("feed", owner.feed_cmd))
    app.add_handler(CallbackQueryHandler(owner.invite_cb, pattern=r"^owner:invite:(model|manager)$"))
    app.add_handler(CallbackQueryHandler(owner.people_cb, pattern=r"^owner:people$"))
    app.add_handler(CallbackQueryHandler(owner.feed_cb, pattern=r"^owner:feed$"))
    app.add_handler(CallbackQueryHandler(owner.deactivate_cb, pattern=r"^owner:deact:\d+$"))

    # Requests: listings + delivery
    app.add_handler(CommandHandler("myrequests", requests.my_requests_cmd))
    app.add_handler(CommandHandler("queue", requests.queue_cmd))
    app.add_handler(CallbackQueryHandler(requests.deliver_cb, pattern=r"^req:deliver:\d+$"))
    app.add_handler(CallbackQueryHandler(requests.menu_cb, pattern=r"^menu:(myrequests|queue)$"))

    # Low-priority text fallback ("just talk to the bot"). Registered LAST in the
    # same group so an active conversation's text step always wins; this only
    # fires for stray text that no conversation consumed. (Handlers in different
    # groups would BOTH run on the same update, so keep it in group 0.)
    app.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, common.fallback_text))

    app.add_error_handler(_on_error)
    return app


def main() -> None:
    config = load_config()
    app = build_application(config)
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
