"""Shared enums, labels and configurable option lists."""

from __future__ import annotations

from enum import Enum


class Role(str, Enum):
    OWNER = "owner"
    MANAGER = "manager"
    MODEL = "model"


class RequestType(str, Enum):
    CUSTOM = "custom"
    RELOAD = "reload"


class RequestStatus(str, Enum):
    PENDING = "pending"
    ACCEPTED = "accepted"
    DENIED = "denied"
    DELIVERED = "delivered"
    CANCELLED = "cancelled"


# Content categories offered for a "reload" request.
# Edit this list to match the kind of content your agency works with.
RELOAD_CONTENT_TYPES = [
    "Nudes",
    "Lewds / teasing",
    "Feet",
    "Photos (SFW)",
    "Video",
    "Other",
]

# Words a model/manager can type to skip an optional free-text step.
SKIP_WORDS = {"skip", "-", "none", "no", "n/a", "na"}


TYPE_LABELS = {
    RequestType.CUSTOM.value: "Custom",
    RequestType.RELOAD.value: "Content reload",
}

ROLE_LABELS = {
    Role.OWNER.value: "Owner",
    Role.MANAGER.value: "Manager",
    Role.MODEL.value: "Model",
}

STATUS_LABELS = {
    RequestStatus.PENDING.value: "⏳ Pending",
    RequestStatus.ACCEPTED.value: "✅ Accepted",
    RequestStatus.DENIED.value: "❌ Declined",
    RequestStatus.DELIVERED.value: "📦 Delivered",
    RequestStatus.CANCELLED.value: "🚫 Cancelled",
}
