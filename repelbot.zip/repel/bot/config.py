"""Configuration loading from environment variables / .env file."""

from __future__ import annotations

import os
from dataclasses import dataclass

try:
    from dotenv import load_dotenv
except ImportError:  # python-dotenv is optional at runtime
    def load_dotenv(*_args, **_kwargs):  # type: ignore
        return False


@dataclass(frozen=True)
class Config:
    bot_token: str
    owner_id: int  # 0 means "not set" — first /start bootstraps the owner
    db_path: str
    state_path: str


def load_config() -> Config:
    """Read configuration from the environment (and a .env file if present)."""
    load_dotenv()

    token = os.getenv("BOT_TOKEN", "").strip()
    if not token:
        raise RuntimeError(
            "BOT_TOKEN is not set. Copy .env.example to .env and paste the token "
            "you got from @BotFather."
        )

    owner_raw = os.getenv("OWNER_ID", "").strip()
    try:
        owner_id = int(owner_raw) if owner_raw else 0
    except ValueError as exc:
        raise RuntimeError("OWNER_ID must be a numeric Telegram user id.") from exc

    db_path = os.getenv("DB_PATH", "repel.db").strip() or "repel.db"
    state_path = os.getenv("STATE_PATH", "repel_state.pickle").strip() or "repel_state.pickle"

    return Config(
        bot_token=token,
        owner_id=owner_id,
        db_path=db_path,
        state_path=state_path,
    )
