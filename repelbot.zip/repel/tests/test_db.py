"""Unit tests for the SQLite data layer (no Telegram required)."""

import pytest

from bot import db
from bot.constants import RequestStatus, RequestType, Role


@pytest.fixture(autouse=True)
def fresh_db(tmp_path):
    db.configure(str(tmp_path / "test.db"))
    db.init_db()
    yield


def test_user_lifecycle():
    assert db.count_users() == 0
    db.create_user(1, Role.OWNER.value, "Owner", "owner")
    db.create_user(2, Role.MODEL.value, "Bella", "bella")
    assert db.count_users() == 2

    bella = db.get_user(2)
    assert bella["role"] == Role.MODEL.value
    assert bella["is_active"] == 1

    db.touch_user(2, "Bella B", "bellab")
    assert db.get_user(2)["display_name"] == "Bella B"

    db.set_active(2, False)
    assert db.get_user(2)["is_active"] == 0
    assert db.list_by_role(Role.MODEL.value) == []  # active_only by default
    assert len(db.list_by_role(Role.MODEL.value, active_only=False)) == 1


def test_invite_is_single_use():
    code = db.create_invite(Role.MANAGER.value, None, created_by=1)
    invite = db.get_invite(code)
    assert invite["role"] == Role.MANAGER.value
    assert invite["used_by"] is None

    assert db.consume_invite(code, used_by=99) is True
    assert db.consume_invite(code, used_by=100) is False  # already used
    assert db.get_invite(code)["used_by"] == 99


def test_request_accept_flow():
    db.create_user(1, Role.MANAGER.value, "John", None)
    db.create_user(2, Role.MODEL.value, "Bella", None)

    req_id = db.create_request(
        requester_id=1, model_id=2, type_=RequestType.CUSTOM.value,
        content_type=None, details="3 min JOI",
    )
    req = db.get_request(req_id)
    assert req["status"] == RequestStatus.PENDING.value
    assert req["details"] == "3 min JOI"

    db.update_request(req_id, status=RequestStatus.ACCEPTED.value, eta="Tomorrow 8pm")
    req = db.get_request(req_id)
    assert req["status"] == RequestStatus.ACCEPTED.value
    assert req["eta"] == "Tomorrow 8pm"

    db.update_request(req_id, status=RequestStatus.DELIVERED.value)
    assert db.get_request(req_id)["status"] == RequestStatus.DELIVERED.value


def test_request_decline_flow():
    db.create_user(1, Role.MANAGER.value, "John", None)
    db.create_user(2, Role.MODEL.value, "Bella", None)
    req_id = db.create_request(1, 2, RequestType.RELOAD.value, "Nudes", None)

    db.update_request(req_id, status=RequestStatus.DENIED.value, decline_reason="Busy this week")
    req = db.get_request(req_id)
    assert req["status"] == RequestStatus.DENIED.value
    assert req["decline_reason"] == "Busy this week"


def test_request_listings():
    db.create_user(1, Role.MANAGER.value, "John", None)
    db.create_user(2, Role.MODEL.value, "Bella", None)
    db.create_user(3, Role.MODEL.value, "Mia", None)

    db.create_request(1, 2, RequestType.CUSTOM.value, None, "a")
    db.create_request(1, 3, RequestType.CUSTOM.value, None, "b")
    pending_for_bella = db.create_request(1, 2, RequestType.RELOAD.value, "Feet", None)

    assert len(db.list_requests_by_requester(1)) == 3
    bella_pending = db.list_requests_for_model(2, [RequestStatus.PENDING.value])
    assert {r["id"] for r in bella_pending} == {
        r["id"] for r in db.list_requests_for_model(2, [RequestStatus.PENDING.value])
    }
    assert pending_for_bella in {r["id"] for r in bella_pending}
    assert len(db.list_recent_requests()) == 3
