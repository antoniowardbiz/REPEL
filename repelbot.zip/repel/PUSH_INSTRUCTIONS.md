# How to get this code into your GitHub repo

I (Claude) couldn't push it for you because the Claude GitHub App isn't
*installed* on your account with write access — only "authorized" for reading.
So here are two easy ways to do it yourself. **Option A needs no Terminal.**

---

## Option A — Upload on the GitHub website (easiest, no Terminal)

1. **Unzip** the file I sent you (double-click `repel-bot.zip` on your Mac).
   You'll get a folder called **`repel`**.
2. Go to **https://github.com/antoniowardbiz/repel** in your browser.
3. Click the link **"uploading an existing file"** (on the empty-repo page),
   or the **Add file ▸ Upload files** button.
4. Open the unzipped **`repel`** folder, select **everything inside it**
   (the `bot` folder, `tests` folder, `main.py`, `README.md`, etc.) and
   **drag it onto the GitHub page**. GitHub keeps the folder structure.
5. Scroll down and click **Commit changes**.

Done — your code is now in the repo. (You can skip `push.sh`, `.gitignore`
will be uploaded too which is fine.)

---

## Option B — One command in Terminal (if you use git)

1. Unzip the file. Open **Terminal** and go into the folder, e.g.:
   ```
   cd ~/Downloads/repel
   ```
2. Run:
   ```
   bash push.sh
   ```
   The first time, GitHub will ask you to log in — approve it. That's it.

---

## After it's uploaded — running the bot

See **README.md** for full setup, but the short version:

1. Message **@BotFather** on Telegram → `/newbot` → copy the token.
2. Copy `.env.example` to `.env` and paste the token into `BOT_TOKEN`.
3. `pip install -r requirements.txt`
4. `python main.py`
5. Message your bot `/start` — you become the owner and can invite your
   models and chatting managers.
