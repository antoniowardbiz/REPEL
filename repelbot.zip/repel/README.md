# REPEL

A Telegram bot that lets your chatting managers / agency request content from
your models — **customs** and **content reloads** — straight from their phone.
Requests land in the model's inbox, she taps **Accept** (and adds an ETA) or
**Decline**, and both you (the owner) and the requesting manager are kept in the
loop automatically.

---

## How it works

Three roles:

| Role | What they do |
|------|--------------|
| 👑 **Owner** (you) | Invites people, sees every request, can also raise requests. |
| 🧑‍💼 **Manager / agency** | Raises requests for the models they look after. |
| 💃 **Model** | Receives requests in her DM, accepts (with an ETA) or declines, marks delivered. |

### Request flow

```
Manager taps "📝 New request"
        │
        ▼
  Pick model → Custom or Content reload → add details
        │
        ▼
  ➡️  Sent straight to the model's inbox
        │
        ├── ✅ Accept → bot asks "When will it be ready?" → ETA saved
        │            → Owner + Manager notified
        │            → later: model taps "📦 Mark delivered"
        │
        └── ❌ Decline → optional reason → Owner + Manager notified
```

Request types (configurable in `bot/constants.py`):
- **Custom** — free-text description of the custom.
- **Content reload** — pick a category (Nudes, Lewds, Feet, Video, …) plus optional notes.
- The **model fills in the ETA** when she accepts.

> The default routing is **direct to the model** (per your setup). A review/approval
> step (everything goes to a group you confirm first) can be layered on later — see
> *Extending* below.

---

## Setup

### 1. Create the bot
1. Open [@BotFather](https://t.me/BotFather) on Telegram → `/newbot` → follow prompts.
2. Copy the **token** it gives you.
3. (Recommended) `/setprivacy` → **Disable**, so the bot can read messages it's not directly mentioned in (only matters if you later add it to groups).

### 2. Configure
```bash
cp .env.example .env
# edit .env and paste BOT_TOKEN
```
Leave `OWNER_ID` blank to become the owner automatically on first `/start`, or set
it to your numeric id (from [@userinfobot](https://t.me/userinfobot)) to lock it in.

### 3. Install & run
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python main.py
```

Then message your bot `/start`. You'll be set up as the owner and can invite the
rest of the team.

### 4. Invite your team
From the owner menu tap **➕ Invite model** / **➕ Invite manager** (or use
`/invite model` / `/invite manager`). Each generates a **one-time link** — send it
to the person; when they tap it they're registered automatically.

---

## Running it 24/7

**Docker:**
```bash
docker build -t repel .
docker run -d --name repel --env-file .env -v "$PWD/data:/data" repel
```

**systemd** (`/etc/systemd/system/repel.service`):
```ini
[Unit]
Description=REPEL Telegram bot
After=network-online.target

[Service]
WorkingDirectory=/opt/repel
ExecStart=/opt/repel/.venv/bin/python main.py
Restart=always
EnvironmentFile=/opt/repel/.env

[Install]
WantedBy=multi-user.target
```
```bash
sudo systemctl enable --now repel
```

---

## Project layout

```
main.py                 # entrypoint
bot/
  app.py                # builds the Application, wires handlers
  config.py             # env / .env loading
  constants.py          # roles, request types, content categories  ← edit lists here
  db.py                 # SQLite data layer (dependency-free, unit-tested)
  keyboards.py          # inline keyboards
  texts.py              # message formatting
  handlers/
    common.py           # /start, onboarding, menus, help
    owner.py            # invites, people management, activity feed
    requests.py         # the request wizard + model accept/decline/ETA/deliver
tests/test_db.py        # data-layer tests
```

Data lives in `repel.db` (SQLite) and `repel_state.pickle` (in-progress
conversations). Both are gitignored. Back up `repel.db` to keep your history.

---

## Tests
```bash
pip install -r requirements-dev.txt
pytest
```

---

## Extending

- **Approval / review step** — instead of DMing the model directly in
  `requests.nr_confirm`, post to an owner review chat with Approve/Reject buttons,
  then forward on approval. The status model already supports it.
- **Per-manager → model assignments** — restrict which models a manager can see in
  `nr_start` (filter `db.list_by_role`).
- **ETA reminders** — add `python-telegram-bot[job-queue]` and schedule a nudge near
  the ETA.
- **"Just talk to it" with AI** — parse a manager's free-text message into a
  structured request (model + type + details) with the Claude API, then drop into
  the confirm step. The free-text fallback hook is already in `common.fallback_text`.
- **Edit the request categories** — change `RELOAD_CONTENT_TYPES` in
  `bot/constants.py`.

---

## Notes on privacy & safety
- The bot is **invite-only**; unknown users get nothing until the owner invites them.
- Each invite link works exactly once.
- Requests are only actionable by the model they're addressed to; every callback is
  ownership-checked.
- No media is stored by the bot — it relays text requests; content itself stays in
  whatever channels you already use (Notion, WhatsApp, etc.).
